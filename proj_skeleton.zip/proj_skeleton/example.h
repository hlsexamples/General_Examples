#ifndef EXAMPLE_H
#define EXAMPLE_H

#define TEST_SIZE 10
typedef int DataType;

void example(DataType DataIn, DataType *DataOut);

#endif
